from tkinter import *
from tkinter import messagebox
from time import sleep
import string
import random
import sqlite3

import string

conn=sqlite3.connect("Password_Manager.db")
conn.execute('''
            create table if not exists Password_Manager(
                
                Platform VARCHAR(50),
                Password VARCHAR(15)
              
            )
''')
conn.commit()
conn.close()

def encrypt(msg):
    
    en=""
    for letter in msg:
        asc=ord(letter)+3
        ench=chr(asc)
        en+=ench
    return en[::-1]
    


def decrypt(msg):
    de = ""

    if not msg:
        return de

    for letter in msg:
        asc = ord(letter) - 3
        ench = chr(asc)
        de += ench
    return de[::-1]

    

def search_password(platform):
    # Connect to the database
    conn = sqlite3.connect("Password_Manager.db")
    cursor = conn.cursor()
    # Execute the query to find the password for the given platform
    cursor.execute("SELECT Password FROM Password_Manager WHERE Platform=?", (platform,))
    # Fetch the result
    result = cursor.fetchone()
    conn.close()
    # If a result is found, decrypt the password and return it
    if result:
        return decrypt(result[0])
    else:
        return None
  
  
def insert_data(platform, password):
    
    conn = sqlite3.connect("Password_Manager.db")
    cursor = conn.cursor()
    cursor.execute("INSERT INTO Password_Manager (platform, password) VALUES (?, ?)", (platform, password))
    conn.commit()
    conn.close()

        

def signup():
    platform_value = U_entry.get()
    password_value = P_entry.get()
   # encrypt(password_value)

    if not platform_value or not password_value:
        messagebox.showerror("Error", "Please enter both Platform and password")
        return
    encrypted_value=encrypt(password_value)
    insert_data(platform_value,encrypted_value)  # Call the insert_data function to insert data into the database
    messagebox.showinfo("Success", "Data inserted into the Password Manager database")






def search_win():
    def search():
        platform_value = platform_entry.get()
        extracted_password = search_password(platform_value)
        if extracted_password:
            pass_entry.delete(0, END)
            pass_entry.insert(0, extracted_password)
        else:
            messagebox.showinfo("Info", "Password not found for the given platform")

    s_win = Toplevel()
    s_win.minsize(300, 300)
    s_win.maxsize(300, 300)
    s_win.title("Search For Password")
    s_win.configure(background='coral')

    Label(s_win, text="Enter Platform:").pack()
    platform_entry = Entry(s_win)
    platform_entry.pack(pady=(10, 20))

    Label(s_win, text="Extracted Password is:").pack()
    pass_entry = Entry(s_win)
    pass_entry.pack(pady=(10, 20))

    btn_search = Button(s_win, text="Search", command=search)
    btn_search.pack(pady=(10, 20))


    




def create_win():
    ex_win = Toplevel()

    def copy():
        root.clipboard_clear()#clears the clipboard
        root.clipboard_append(label_out.get()) #copy the text to the clipboard

    def gen():
        password = []
        #this deletes the previously generated Password,every time we press generate.
        label_out.delete(0, END)

        for i in range(5):
            alpha = random.choice(string.ascii_letters)
            symbol = random.choice(string.punctuation)
            numbers = random.choice(string.digits)
            password.append(alpha)
            password.append(symbol)
            password.append(numbers)
    

        messagebox.showinfo('Status', 'Generating...')
        sleep(1)
        s = "".join(str(x) for x in password)
        label_out.insert(0, s)
        sleep(1)
        messagebox.showinfo('Result', 'Password Successfully Generated.')

    ex_win.title('Password Generator')
    ex_win.geometry('500x500')
    ex_win.configure(background='Grey')

    t_label = Label(ex_win, text='Press Button Below to Generate Password', fg='black', bg='#00FF00')
    t_label.pack()
    t_label.config(font=('forte', 20))

    butn = Button(ex_win, text='Generate Password', bg='white', fg='black', command=gen)
    butn.pack(pady=(100, 20))
    label_out = Entry(ex_win, font=('Times new roman', 18), fg='black')
    label_out.pack(pady=(20, 20))

    bt_cp = Button(ex_win, text="Copy Password", bg='white', fg='black', command=copy)
    bt_cp.pack(pady=(50, 20))


root = Tk()
root.title('Password Manager')
root.minsize(400, 500)
root.maxsize(400, 500)
root.grid_rowconfigure(1, weight=0)
root.grid_columnconfigure(1, weight=0)

img_path = PhotoImage(file=r"C:\Users\rohan\Desktop\Project\Network-PNG-Free-Download.png")
back_label =Label(root,image=img_path)
back_label.place(x=0,y=1,relwidth=1,relheight=2)

title = Label(root, text="Enter Details", font=('Arial', 10,))
title.grid(row=0, columnspan=10)
title.config(anchor=CENTER)

Username_label = Label(root, text="Username/Platform:", font=('forte', 15))
Username_label.grid(row=10, column=0, ipady=50, ipadx=25)
U_entry = Entry(root, width=40)
U_entry.grid(row=10, column=1)

pass_label = Label(root, text="Password:", font=('forte', 15))
pass_label.grid(row=20, column=0, ipady=10)
P_entry = Entry(root, width=40)
P_entry.grid(row=20, column=1)

gen_rec = Button(root, text="Autorecommend Password", command=create_win)
gen_rec.grid(row=500, column=0, columnspan=10)

btn_insert = Button(root, text="Enter to Insert Data",command=signup)
btn_insert.grid(row=1000, column=0, columnspan=100)

btn_search = Button(root, text="Press to search password",command=search_win)
btn_search.grid(row=1500, column=0, columnspan=100)

root.mainloop()
